<div id="portfolio" class="one_half">
	<article>
		<h2><?= ucfirst($productio->service_title)?></h2>
		<p><?= $productio->service_des ?></p>
    </article>
</div>