<div id="portfolio" class="one_half">
	<article>
		<h2>About MTI Trading Limited</h2>
		<img class="borderedbox" src="<?= base_url(); ?>uploads/about/<?= $about->about_image_path; ?>" alt="<?= $about->about_image_path; ?>">
		<p><?= $about->about_des?></p>
    </article>
</div>